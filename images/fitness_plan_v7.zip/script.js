
const workoutData = {
  beginner: [
    [
      { name: "Bodyweight Squats", img: "https://via.placeholder.com/400x250?text=Squats", tips: ["15 reps.", "Keep your back straight."] },
      { name: "Wall Push", img: "https://via.placeholder.com/400x250?text=Wall+Push", tips: ["10 reps.", "Maintain posture."] },
      { name: "Arm Circles", img: "https://via.placeholder.com/400x250?text=Arm+Circles", tips: ["30 sec.", "Rotate slowly."] },
      { name: "Step Touch", img: "https://via.placeholder.com/400x250?text=Step+Touch", tips: ["20 steps.", "Maintain balance."] },
      { name: "Cat Stretch", img: "https://via.placeholder.com/400x250?text=Cat+Stretch", tips: ["10 reps.", "Breathe deeply."] }
    ],
    [
      { name: "Brisk Walk", img: "https://via.placeholder.com/400x250?text=Brisk+Walk", tips: ["20 min.", "Steady pace."] },
      { name: "Crunches", img: "https://via.placeholder.com/400x250?text=Crunches", tips: ["20 reps.", "Engage core."] },
      { name: "Glute Bridge", img: "https://via.placeholder.com/400x250?text=Glute+Bridge", tips: ["15 reps.", "Squeeze at top."] },
      { name: "Leg Raises", img: "https://via.placeholder.com/400x250?text=Leg+Raises", tips: ["10 reps.", "Controlled motion."] },
      { name: "Ankle Taps", img: "https://via.placeholder.com/400x250?text=Ankle+Taps", tips: ["20 taps.", "Engage obliques."] }
    ],
    [
      { name: "Seated Arm Stretch", img: "https://via.placeholder.com/400x250?text=Seated+Stretch", tips: ["20 sec.", "Relax shoulders."] },
      { name: "Bicep Curls", img: "https://via.placeholder.com/400x250?text=Bicep+Curls", tips: ["10 reps.", "Controlled lift."] },
      { name: "Tricep Dips", img: "https://via.placeholder.com/400x250?text=Tricep+Dips", tips: ["10 reps.", "Elbows close."] },
      { name: "Shoulder Taps", img: "https://via.placeholder.com/400x250?text=Shoulder+Taps", tips: ["15 taps.", "Keep hips stable."] },
      { name: "Marching in Place", img: "https://via.placeholder.com/400x250?text=March", tips: ["20 steps.", "Lift knees high."] }
    ],
    [
      { name: "Light Yoga", img: "https://via.placeholder.com/400x250?text=Yoga", tips: ["20 min.", "Focus on breathing."] },
      { name: "Butterfly Stretch", img: "https://via.placeholder.com/400x250?text=Stretch", tips: ["30 sec.", "Relax muscles."] },
      { name: "Breathing Exercise", img: "https://via.placeholder.com/400x250?text=Breathing", tips: ["1 min.", "Inhale/exhale slowly."] },
      { name: "Neck Roll", img: "https://via.placeholder.com/400x250?text=Neck+Roll", tips: ["10 rolls.", "Gentle rotation."] },
      { name: "Child Pose", img: "https://via.placeholder.com/400x250?text=Child+Pose", tips: ["30 sec.", "Stretch back."] }
    ],
    [
      { name: "Standing Kickbacks", img: "https://via.placeholder.com/400x250?text=Kickbacks", tips: ["15 reps.", "Control motion."] },
      { name: "Lunges", img: "https://via.placeholder.com/400x250?text=Lunges", tips: ["10 reps each.", "Keep knees aligned."] },
      { name: "Side Raises", img: "https://via.placeholder.com/400x250?text=Side+Raises", tips: ["15 reps.", "Engage shoulders."] },
      { name: "Jumping Jacks", img: "https://via.placeholder.com/400x250?text=Jumping+Jacks", tips: ["20 reps.", "Soft landings."] },
      { name: "Side Bends", img: "https://via.placeholder.com/400x250?text=Side+Bends", tips: ["15 reps.", "Stretch obliques."] }
    ],
    [
      { name: "Jog in Place", img: "https://via.placeholder.com/400x250?text=Jog", tips: ["2 min.", "Maintain rhythm."] },
      { name: "Plank", img: "https://via.placeholder.com/400x250?text=Plank", tips: ["20 sec.", "Keep body straight."] },
      { name: "Flutter Kicks", img: "https://via.placeholder.com/400x250?text=Flutter+Kicks", tips: ["20 sec.", "Control legs."] },
      { name: "High Knees", img: "https://via.placeholder.com/400x250?text=High+Knees", tips: ["10 reps.", "Pump arms."] },
      { name: "Jump Squats", img: "https://via.placeholder.com/400x250?text=Jump+Squats", tips: ["10 reps.", "Land softly."] }
    ],
    [
      { name: "Yoga", img: "https://via.placeholder.com/400x250?text=Yoga", tips: ["20 min.", "Focus on breathing."] },
      { name: "Hamstring Stretch", img: "https://via.placeholder.com/400x250?text=Hamstring", tips: ["30 sec.", "Hold gently."] },
      { name: "Deep Breathing", img: "https://via.placeholder.com/400x250?text=Breathing", tips: ["5 min.", "Calm your mind."] },
      { name: "Cobra Stretch", img: "https://via.placeholder.com/400x250?text=Cobra", tips: ["10 reps.", "Hold for 3 sec."] },
      { name: "Child Pose", img: "https://via.placeholder.com/400x250?text=Child+Pose", tips: ["10 sec.", "Relax fully."] }
    ]
  ],
  intermediate: [
    [
      { name: "Dumbbell Squats", img: "https://via.placeholder.com/400x250?text=Dumbbell+Squats", tips: ["12 reps.", "Hold dumbbells securely."] },
      { name: "Glute Bridge", img: "https://via.placeholder.com/400x250?text=Glute+Bridge", tips: ["10 reps.", "Engage glutes fully."] },
      { name: "Jumping Jacks", img: "https://via.placeholder.com/400x250?text=Jumping+Jacks", tips: ["30 reps.", "Land softly."] },
      { name: "DB Shoulder Press", img: "https://via.placeholder.com/400x250?text=Shoulder+Press", tips: ["10 reps.", "Press overhead."] },
      { name: "Bicycle Crunches", img: "https://via.placeholder.com/400x250?text=Bicycle+Crunches", tips: ["20 reps.", "Rotate torso fully."] }
    ],
    [
      { name: "Treadmill", img: "https://via.placeholder.com/400x250?text=Treadmill", tips: ["20 min.", "Steady pace."] },
      { name: "Push-ups", img: "https://via.placeholder.com/400x250?text=Push-ups", tips: ["10 reps.", "Body straight."] },
      { name: "Plank", img: "https://via.placeholder.com/400x250?text=Plank", tips: ["1 min.", "Engage core."] },
      { name: "Side Plank", img: "https://via.placeholder.com/400x250?text=Side+Plank", tips: ["30 sec each.", "Keep hips up."] },
      { name: "Flutter Kicks", img: "https://via.placeholder.com/400x250?text=Flutter+Kicks", tips: ["20 sec.", "Controlled."] }
    ],
    // (Additional days for intermediate here)
  ],
  advanced: [
    [
      { name: "Barbell Back Squats", img: "https://via.placeholder.com/400x250?text=Back+Squats", tips: ["8 reps.", "Keep spine neutral."] },
      { name: "Jump Squats", img: "https://via.placeholder.com/400x250?text=Jump+Squats", tips: ["12 reps.", "Explode upward with power."] },
      { name: "Hip Thrusts", img: "https://via.placeholder.com/400x250?text=Hip+Thrusts", tips: ["10 reps.", "Pause at top for 2 sec."] },
      { name: "Cable Kickbacks", img: "https://via.placeholder.com/400x250?text=Cable+Kickbacks", tips: ["12 reps.", "Extend fully."] },
      { name: "Ab Crunch Machine", img: "https://via.placeholder.com/400x250?text=Ab+Crunch", tips: ["15 reps.", "Control motion."] }
    ]
    // (Additional days for advanced here)
  ]
};

let currentLevel = '';

function showDays(level) {
  currentLevel = level;
  document.getElementById('levels-page').style.display = 'none';
  document.getElementById('days-page').style.display = 'block';
  document.getElementById('level-title').innerText = level.charAt(0).toUpperCase() + level.slice(1) + " Level";
  document.getElementById('workout-tasks').innerHTML = '';
}

function backToLevels() {
  document.getElementById('days-page').style.display = 'none';
  document.getElementById('levels-page').style.display = 'block';
}

function showWorkouts(day) {
  const workoutDiv = document.getElementById('workout-tasks');
  workoutDiv.innerHTML = '';

  const exercises = workoutData[currentLevel][day - 1] || [];

  let content = `<div class="workout-card"><h3>Day ${day} Workout</h3>`;
  exercises.forEach(ex => {
    content += `
      <div class="exercise">
        <img src="${ex.img}" alt="${ex.name}">
        <ul class="exercise-text">
          <li>${ex.tips[0]}</li>
          <li>${ex.tips[1]}</li>
        </ul>
      </div>`;
  });
  content += `</div>`;

  workoutDiv.innerHTML = content;
  workoutDiv.scrollIntoView({ behavior: 'smooth' });
}
